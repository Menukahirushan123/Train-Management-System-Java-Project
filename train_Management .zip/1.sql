CREATE DATABASE IF NOT EXISTS train_reservation_db;
USE train_reservation_db;

CREATE TABLE trains (
    train_id INT AUTO_INCREMENT PRIMARY KEY,
    train_name VARCHAR(100) NOT NULL,
    total_seats INT NOT NULL,
    ticket_price DECIMAL(10, 2) NOT NULL,
    source VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    available_seats INT DEFAULT 0
);

CREATE TABLE passengers (
    passenger_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    contact_number VARCHAR(15) CHECK (contact_number REGEXP '^07[0-9]{8}$'), 
    email VARCHAR(100) CHECK (email LIKE '%@gmail.com'), 
    gender VARCHAR(10),
    age INT,
    train_id INT,
    CONSTRAINT fk_passenger_train 
        FOREIGN KEY (train_id) 
        REFERENCES trains(train_id) 
        ON DELETE SET NULL 
        ON UPDATE CASCADE
);

CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    passenger_id INT NOT NULL,
    train_id INT NOT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_passenger 
        FOREIGN KEY (passenger_id) 
        REFERENCES passengers(passenger_id) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    CONSTRAINT fk_booking_train 
        FOREIGN KEY (train_id) 
        REFERENCES trains(train_id) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE
);


SELECT 
    (SELECT COUNT(*) FROM trains) AS total_trains,
    (SELECT COUNT(*) FROM passengers) AS total_passengers,
    (SELECT COUNT(*) FROM bookings) AS total_bookings;