package com.mycompany.trainmanagement;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PassengerManagementStyle {

    public static void styleFormComponents(JLabel[] labels, JTextField[] fields, JComboBox<String> comboBox, JPanel panel) {
        Color textColor = new Color(248, 250, 252);
        Color inputBg = new Color(40, 50, 70);
        Font boldFont = new Font("Segoe UI", Font.BOLD, 14);

        for (JLabel lbl : labels) {
            if (lbl != null) {
                lbl.setForeground(textColor);
                lbl.setFont(boldFont);
            }
        }

        for (JTextField field : fields) {
            if (field != null) {
                field.setBackground(inputBg);
                field.setForeground(textColor);
                field.setCaretColor(textColor);
                field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(70, 130, 180, 150), 1),
                    BorderFactory.createEmptyBorder(5, 8, 5, 8)
                ));
            }
        }

        if (comboBox != null) {
            comboBox.setBackground(inputBg);
            comboBox.setForeground(textColor);
        }

        if (panel != null) {
            panel.setBackground(new Color(15, 23, 42, 220));
        }
    }

    public static void styleCustomTable(JScrollPane scrollPane, JTable table) {
        if (scrollPane != null) {
            scrollPane.setOpaque(false);
            scrollPane.getViewport().setOpaque(false);
            scrollPane.setBorder(BorderFactory.createLineBorder(new Color(59, 130, 246, 100), 1));
        }
        if (table != null) {
            table.setBackground(new Color(30, 41, 59, 220));
            table.setForeground(new Color(248, 250, 252));
            table.setSelectionBackground(new Color(59, 130, 246));
            table.setSelectionForeground(Color.WHITE);
            table.getTableHeader().setBackground(new Color(15, 23, 42));
            table.getTableHeader().setForeground(Color.WHITE);
            table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
            table.setRowHeight(28);
        }
    }

    public static void styleFlatButton(JButton btn, Color bgColor) {
        if (btn != null) {
            btn.setBackground(bgColor);
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setContentAreaFilled(false); // Custom painting සඳහා මෙය අත්‍යවශ්‍ය වේ
            btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

            List<ButtonParticle> particles = new ArrayList<>();
            Random rand = new Random();

            // Timer එකක් මඟින් බොත්තම මත තිත් චලනය වීම පාලනය කරයි
            Timer particleTimer = new Timer(20, e -> {
                if (btn.getModel().isRollover()) {
                    // මූවුස් එක තැබූ විට එකවර අලුත් තිත් ගොඩක් (වරකට 6 බැගින්) එකතු වේ
                    for (int k = 0; k < 6; k++) {
                        particles.add(new ButtonParticle(
                            rand.nextInt(Math.max(1, btn.getWidth())),
                            btn.getHeight() / 2 + (rand.nextInt(16) - 8),
                            (rand.nextFloat() - 0.5f) * 5.0f, // තිත් දෙපැත්තට විහිදෙන වේගය
                            -(rand.nextFloat() * 3.5f + 1.5f), // උඩට විහිදෙන වේගය
                            rand.nextInt(4) + 2              // තිත්වල ප්‍රමාණය
                        ));
                    }
                }

                for (int i = 0; i < particles.size(); i++) {
                    ButtonParticle p = particles.get(i);
                    p.update();
                    if (p.alpha <= 0) {
                        particles.remove(i);
                        i--;
                    }
                }
                btn.repaint();
            });
            particleTimer.start();

            // Custom UI එකක් මඟින් බොත්තම සහ තිත් එකම තිරයක render කරයි
            btn.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
                @Override
                public void paint(Graphics g, JComponent c) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                    boolean isHovered = btn.getModel().isRollover();

                    // බොත්තමේ පසුබිම් වර්ණය සහ Hover වූ විට දීප්තිය වැඩිවීම
                    g2.setColor(isHovered ? bgColor.brighter().brighter() : bgColor);
                    g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 10, 10);

                    // බොත්තම වටා ඇති බෝඩරය
                    g2.setColor(isHovered ? new Color(147, 197, 253, 255) : new Color(255, 255, 255, 150));
                    g2.setStroke(new BasicStroke(1.5f));
                    g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 10, 10);

                    // බොත්තමෙන් විහිදී යන තිත් (Particles) ඇඳීම
                    for (ButtonParticle p : particles) {
                        p.draw(g2);
                    }

                    g2.dispose();
                    super.paint(g, c);
                }
            });
        }
    }

    // බොත්තම මත පාවෙන තිත් සඳහා Class එකක්
    private static class ButtonParticle {
        float x, y, vx, vy;
        float alpha = 1.0f;
        int size;

        ButtonParticle(float x, float y, float vx, float vy, int size) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.size = size;
        }

        void update() {
            x += vx;
            y += vy;
            alpha -= 0.035f; // ක්‍රමයෙන් මැකී යාම
            if (alpha < 0) alpha = 0;
        }

        void draw(Graphics2D g2) {
            g2.setColor(new Color(255, 255, 255, Math.max(0, Math.min(255, (int) (alpha * 255)))));
            g2.fillOval((int) x, (int) y, size, size);
        }
    }

    public static class FloatingBubblesPanel extends JPanel {
        private final java.util.List<Bubble> bubbles = new ArrayList<>();
        private final java.util.List<Sparkle> sparkles = new ArrayList<>();

        public FloatingBubblesPanel() {
            setOpaque(false);
            Random rand = new Random();

            for (int i = 0; i < 30; i++) {
                bubbles.add(new Bubble(rand.nextInt(1200), rand.nextInt(800), rand.nextInt(35) + 15, rand.nextFloat() * 1.5f + 0.5f));
            }

            for (int i = 0; i < 40; i++) {
                sparkles.add(new Sparkle(rand.nextInt(1200), rand.nextInt(800), rand.nextInt(3) + 2, rand.nextFloat() * 2.0f + 1.0f));
            }

            Timer timer = new Timer(20, e -> {
                for (Bubble b : bubbles) {
                    b.y -= b.speed;
                    if (b.y < -50) {
                        b.y = getHeight() + 50;
                        b.x = rand.nextInt(Math.max(1, getWidth()));
                    }
                }

                for (Sparkle s : sparkles) {
                    s.y -= s.speed;
                    if (s.y < 0) {
                        s.y = getHeight() + 10;
                        s.x = rand.nextInt(Math.max(1, getWidth()));
                    }
                }
                repaint();
            });
            timer.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            GradientPaint gp = new GradientPaint(0, 0, new Color(8, 12, 22), 0, getHeight(), new Color(15, 23, 42));
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());

            for (Bubble b : bubbles) {
                g2.setColor(new Color(59, 130, 246, 50));
                g2.fillOval((int) b.x, (int) b.y, b.size, b.size);
                
                g2.setColor(new Color(147, 197, 253, 120));
                g2.drawOval((int) b.x, (int) b.y, b.size, b.size);
            }

            for (Sparkle s : sparkles) {
                g2.setColor(new Color(255, 255, 255, 180));
                g2.fillOval((int) s.x, (int) s.y, s.size, s.size);
            }

            g2.dispose();
        }

        private static class Bubble {
            float x, y;
            int size;
            float speed;

            Bubble(float x, float y, int size, float speed) {
                this.x = x;
                this.y = y;
                this.size = size;
                this.speed = speed;
            }
        }

        private static class Sparkle {
            float x, y;
            int size;
            float speed;

            Sparkle(float x, float y, int size, float speed) {
                this.x = x;
                this.y = y;
                this.size = size;
                this.speed = speed;
            }
        }
    }
}