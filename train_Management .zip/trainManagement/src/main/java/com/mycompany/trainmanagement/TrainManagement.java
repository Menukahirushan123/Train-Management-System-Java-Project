/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trainmanagement;

/**
 *
 * @author Administrator
 */
public class TrainManagement {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
