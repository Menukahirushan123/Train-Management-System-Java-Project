package com.mycompany.trainmanagement;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;

public class UIStyleHelper {

    // 1. Transparent Panel Helper
    public static void makePanelTransparent(JPanel panel) {
        panel.setOpaque(false);
    }

    // 2. Animated Particle Glow Button Style
    public static void applyAnimatedParticleGlowButtonStyle(JButton btn, Color baseBg, Color glowColor, boolean isActive) {
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setForeground(Color.WHITE);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        List<Particle> particles = new ArrayList<>();
        Random random = new Random();

        Timer timer = new Timer(20, e -> {
            boolean isHovered = btn.getModel().isRollover();
            
            if (isHovered || isActive) {
                if (particles.size() < 25) {
                    particles.add(new Particle(
                        random.nextInt(Math.max(1, btn.getWidth())),
                        btn.getHeight(),
                        random.nextFloat() * 2 - 1,
                        -(random.nextFloat() * 2 + 1),
                        random.nextInt(4) + 2,
                        glowColor
                    ));
                }
            }

            for (int i = 0; i < particles.size(); i++) {
                Particle p = particles.get(i);
                p.update();
                if (p.alpha <= 0) {
                    particles.remove(i);
                    i--;
                }
            }
            btn.repaint();
        });
        timer.start();

        btn.setUI(new BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                boolean isHovered = btn.getModel().isRollover();

                if (isHovered || isActive) {
                    g2.setColor(new Color(glowColor.getRed(), glowColor.getGreen(), glowColor.getBlue(), isHovered ? 90 : 50));
                    g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 12, 12);
                }

                g2.setColor(isHovered ? glowColor.darker() : baseBg);
                g2.fillRoundRect(2, 2, c.getWidth() - 4, c.getHeight() - 4, 10, 10);

                for (Particle p : particles) {
                    p.draw(g2);
                }

                g2.setColor(isActive || isHovered ? glowColor : new Color(71, 85, 105));
                g2.drawRoundRect(2, 2, c.getWidth() - 5, c.getHeight() - 5, 10, 10);

                g2.dispose();
                super.paint(g, c);
            }
        });
    }

    private static class Particle {
        float x, y, vx, vy;
        float alpha = 1.0f;
        int size;
        Color color;

        Particle(float x, float y, float vx, float vy, int size, Color color) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.size = size;
            this.color = color;
        }

        void update() {
            x += vx;
            y += vy;
            alpha -= 0.03f;
            if (alpha < 0) alpha = 0;
        }

        void draw(Graphics2D g2) {
            g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (alpha * 255)));
            g2.fillOval((int) x, (int) y, size, size);
        }
    }

    // 3. Custom Table Style Helper
    public static void styleCustomTable(JScrollPane scrollPane, JTable table) {
        table.setBackground(new Color(15, 23, 42));
        table.setForeground(new Color(226, 232, 240));
        table.setGridColor(new Color(51, 65, 85));
        table.setRowHeight(35);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(30, 41, 59));
        table.getTableHeader().setForeground(new Color(148, 163, 184));
        scrollPane.getViewport().setBackground(new Color(15, 23, 42));
    }

    // 4. Moving Bubbles Background Panel
    public static class FloatingBubblesPanel extends JPanel {
        private final List<Bubble> bubbles = new ArrayList<>();

        public FloatingBubblesPanel() {
            setBackground(new Color(15, 23, 42));
            Random rand = new Random();

            for (int i = 0; i < 20; i++) {
                bubbles.add(new Bubble(rand.nextInt(800), rand.nextInt(600), rand.nextInt(30) + 10, rand.nextFloat() * 1.5f + 0.5f));
            }

            Timer timer = new Timer(30, e -> {
                for (Bubble b : bubbles) {
                    b.y -= b.speed;
                    if (b.y < -50) {
                        b.y = getHeight() + 50;
                        b.x = rand.nextInt(Math.max(1, getWidth()));
                    }
                }
                repaint();
            });
            timer.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            for (Bubble b : bubbles) {
                g2.setColor(new Color(59, 130, 246, 30));
                g2.fillOval((int) b.x, (int) b.y, b.size, b.size);
            }

            g2.dispose();
        }

        private static class Bubble {
            float x, y;
            int size;
            float speed;

            Bubble(float x, float y, int size, float speed) {
                this.x = x;
                this.y = y;
                this.size = size;
                this.speed = speed;
            }
        }
    }
}